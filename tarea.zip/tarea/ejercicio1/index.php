<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Conversion</title>
</head>
<body>
    <h1>Bienvenidos</h1>
    
    <form method="POST" action="conversion.php">
        <label>Grados celsius</label><br>
        <input type="number" name="numero1" required placeholder="Digite los grados celsius">
        <input type="submit" value="Convertir">
        
    </form>
</body>
</html>