<?php

class Grados{
    public $gCentigradoss;

    public function __construct($_gCentigradoss)
    {
        $this->gCentigradoss = $_gCentigradoss;
    }

    public function sumar()
    {
        echo "Grados centigrados: ". $this->gCentigradoss;
        echo "<br>";
        echo "Los grados Centigrados en Farenheit son: " .($this->gCentigradoss * 9/5 + 32);

    }
}

$total = new Grados($_POST['numero1']);
$total->sumar();
?>