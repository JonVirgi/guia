<?php
class Imagen{
    public function Img(){
        if($_SERVER["REQUEST_METHOD"] == "POST"){
            for($i = 1; $i <= $_POST["numero"]; $i ++){
                echo '<img src="img/greninja.jpg" width="500" height="600">';
                echo '<br>';
            }
        }
    }
}
$img = new Imagen();
$img->Img();
?>