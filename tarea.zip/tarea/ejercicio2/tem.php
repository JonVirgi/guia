<?php
class Tem{
    public $temperatura;

    public function __construct($_temperatura)
    {
        $this->temperatura = $_temperatura;
    }

    public function tempe()
    {
        if ($this->temperatura <= 0){
            echo "<h1 style='color:blue'>Temperatura maximamente fria</h1>";
        }

        else if($this->temperatura > 0 && $this->temperatura <=30){
            echo "<h1 style='color:yellow'>Temperatura estable</h1>";
        }

        else if($this->temperatura >= 31 && $this->temperatura <=100){
            echo "<h1 style='color:red'>Temperatura maximamente caliente</h1>";
        }

        else{
            echo "<h1>Ingrese valores validos</h1>";
        }
    }
}
$valor = new Tem($_POST['Temperatura']);
$valor->tempe();
?>